package com.vehiclemanagement.controller;

import com.vehiclemanagement.model.AccidentReport;
import com.vehiclemanagement.model.Vehicle;
import com.vehiclemanagement.service.VehicleManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;

@Controller
public class AccidentReportController {

    @Autowired
    private VehicleManagementService vehicleManagementService;

    // Show the report accident form
    @GetMapping("/report-accident")
    public String showReportAccidentPage() {
        return "report-accident"; // Thymeleaf template for the form
    }

    // Handle form submission to confirm the details
    @PostMapping("/report-accident/confirm-accident")
    public String confirmAccidentDetails(
            @RequestParam("offendingVin") int offendingVin,
            @RequestParam("victimVin") int victimVin,
            @RequestParam("details") String details,
            Model model) {

        // Fetch vehicle data
        Vehicle offendingVehicle = vehicleManagementService.findVehicleByVin(offendingVin);
        Vehicle victimVehicle = vehicleManagementService.findVehicleByVin(victimVin);

        // Handle invalid VINs
        if (offendingVehicle == null || victimVehicle == null) {
            model.addAttribute("error", "One or both VINs are invalid!");
            return "error-page"; // Redirect to an error page if data is invalid
        }

        // Add data to the model for confirmation
        model.addAttribute("offendingVehicle", offendingVehicle);
        model.addAttribute("victimVehicle", victimVehicle);
        model.addAttribute("details", details);

        return "confirm-accident"; // Redirect to the confirmation page
    }

    // Handle the final submission of the accident report
    @PostMapping("/report-accident/submit")
    public String submitAccidentReport(
            @RequestParam("offendingVin") String offendingVin,
            @RequestParam("victimVin") String victimVin,
            @RequestParam("details") String details,
            Model model) {

        // Create a new accident report
    	AccidentReport report = new AccidentReport(
    		    "RPT" + System.currentTimeMillis(),
    		    String.valueOf(offendingVin), // Convert integer offendingVin to string
    		    String.valueOf(victimVin),    // Convert integer victimVin to string
    		    details,
    		    new Date()
    		);
        vehicleManagementService.getAccidentReports().add(report);

        // Mock insurance company reply
        String insuranceReply = "Your accident report has been submitted successfully. Our team will review it shortly.";

        // Add data to the model for the summary page
        model.addAttribute("report", report);
        model.addAttribute("insuranceReply", insuranceReply);

        return "accident-summary"; // Redirect to the summary page
    }
}
