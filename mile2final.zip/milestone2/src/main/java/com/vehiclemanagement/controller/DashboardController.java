package com.vehiclemanagement.controller;

import com.vehiclemanagement.service.VehicleManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    @Autowired
    private VehicleManagementService vehicleManagementService;

    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        model.addAttribute("owners", vehicleManagementService.getOwners());
        model.addAttribute("vehicles", vehicleManagementService.getVehicles());
        model.addAttribute("accidentReports", vehicleManagementService.getAccidentReports());

        return "dashboard";
    }
}
