package com.vehiclemanagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    // Root or Home page
    @GetMapping("/")
    public String homePage() {
        return "index";  // Points to the 'index.html' view
    }

    // Transfer ownership page
    @GetMapping("/currentOwner")
    public String transferOwnershipPage() {
        return "currentOwner";  // Points to the 'transfer-ownership.html' view
    }

    // Report accident page
//    @GetMapping("/report-accident")
//    public String reportAccidentPage() {
//        return "report-accident";  // Points to the 'report-accident.html' view
//    }

    // Dashboard page to display users and vehicles

}
