package com.vehiclemanagement.controller;

import com.vehiclemanagement.model.Owner;
import com.vehiclemanagement.service.VehicleManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TransferOwnershipController {

    @Autowired
    private VehicleManagementService vehicleManagementService;

    /**
     * Render the current owner verification page.
     */
    @GetMapping("/current-owner")
    public String currentOwnerPage() {
        return "currentOwner"; // Render `currentOwner.html`
    }

    /**
     * Handle the submission of the current owner verification form.
     */
    @PostMapping("/verify-current-owner")
    public String verifyOwner(
            @RequestParam(name = "vin") String vin,
            @RequestParam(name = "qid") String currentOwnerQid,
            Model model
    ) {
        try {
            int vinNumber = Integer.parseInt(vin);
            int qidNumber = Integer.parseInt(currentOwnerQid);

            // Check if current owner exists
            Owner currentOwner = vehicleManagementService.getOwners()
                    .stream()
                    .filter(owner -> owner.getQID() == qidNumber)
                    .findFirst()
                    .orElse(null);

            if (currentOwner == null) {
                model.addAttribute("message", "Current owner not found.");
                return "currentOwner";
            }

            // Check for unpaid bills
            boolean hasUnpaidBills = vehicleManagementService.checkUnpaidBills(vinNumber);
            if (hasUnpaidBills) {
                model.addAttribute("message", "Vehicle has unpaid bills. Please pay them first.");
                return "currentOwner";
            }

            // Pass data to the next step
            model.addAttribute("vin", vinNumber);
            model.addAttribute("qid", qidNumber);
            return "newOwner"; // Render `newOwnerDetails.html`
        } catch (Exception e) {
            model.addAttribute("message", "Invalid VIN or QID. Please try again.");
            return "currentOwner";
        }
    }


    @PostMapping("/new-owner")
    public String transferOwnership(
            @RequestParam(name = "vin") String vin,
            @RequestParam(name = "currentOwnerQid") String currentOwnerQid,
            @RequestParam(name = "newOwnerQid") String newOwnerQid,
            @RequestParam(name = "newOwnerName") String newOwnerName,
            Model model
    ) {
      
            int vinNumber = Integer.parseInt(vin);
            int currentQid = Integer.parseInt(currentOwnerQid);
            int newQid = Integer.parseInt(newOwnerQid);

            // Get current owner
            Owner currentOwner = vehicleManagementService.getOwners()
                    .stream()
                    .filter(owner -> owner.getQID() == currentQid)
                    .findFirst()
                    .orElse(null);

            if (currentOwner == null) {
                model.addAttribute("message", "Current owner not found.");
                return "newOwner";
            }

            // Check for unpaid bills
            boolean hasUnpaidBills = vehicleManagementService.checkUnpaidBills(vinNumber);
            if (hasUnpaidBills) {
                model.addAttribute("message", "Vehicle has unpaid bills. Please pay them first.");
                return "newOwner";
            }

            // Check if the new owner exists in the system
            Owner newOwner = vehicleManagementService.getOwners()
                    .stream()
                    .filter(owner -> owner.getQID() == newQid)
                    .findFirst()
                    .orElse(null);

            if (newOwner == null) {
                model.addAttribute("message", "New owner is not registered in the QVR system.");
                return "newOwner";
            }

            // Transfer ownership
            vehicleManagementService.updateVehicleOwner(vinNumber, newOwner);

            vehicleManagementService.prepareRegistrationSticker(vinNumber, newOwner);
            vehicleManagementService.createInvoice(vinNumber);

            model.addAttribute("message", "Ownership transferred successfully.");
            return "transferSuccess";

    }

}
