package com.vehiclemanagement.model;
import java.util.Date;
import java.util.List;

public class Accident {
    private Date date;
    private Date time;
    private String location;
    private String briefDescription;
    private Vehicle victim;
    private Vehicle offendingVehicle;
    private int caseNo;

    public Accident(Date date, Date time, String location, String briefDescription, Vehicle victim, Vehicle offendingVehicle, int caseNo) {
        this.date = date;
        this.time = time;
        this.location = location;
        this.briefDescription = briefDescription;
        this.victim = victim;
        this.offendingVehicle = offendingVehicle;
        this.caseNo = caseNo;
    }
    
    public Accident() {
        
    }
    // Getters and Setters
    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }

    public Date getTime() { return time; }
    public void setTime(Date time) { this.time = time; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getBriefDescription() { return briefDescription; }
    public void setBriefDescription(String briefDescription) { this.briefDescription = briefDescription; }

    public Vehicle getVictim() { return victim; }
    public void setVictim(Vehicle victim) { this.victim = victim; }

    public Vehicle getOffendingVehicle() { return offendingVehicle; }
    public void setOffendingVehicle(Vehicle offendingVehicle) { this.offendingVehicle = offendingVehicle; }

    public int getCaseNo() { return caseNo; }
    public void setCaseNo(int caseNo) { this.caseNo = caseNo; }

    public void createAccidentReport() {
        System.out.println("Accident Report Created for Case No: " + caseNo);
    }
}