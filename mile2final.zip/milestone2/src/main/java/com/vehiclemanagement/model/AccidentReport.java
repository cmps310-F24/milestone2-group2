package com.vehiclemanagement.model;

import java.util.Date;

public class AccidentReport {
    private String reportId;
    private String offendingVin;
    private String victimVin;
    private String details;
    private Date reportDate;

    // No-argument constructor
    public AccidentReport() {
        
    }

    // Constructor with parameters
    public AccidentReport(String reportId, String offendingVin, String victimVin, String details, Date reportDate) {
        this.reportId = reportId;
        this.offendingVin = offendingVin;
        this.victimVin = victimVin;
        this.details = details;
        this.reportDate = reportDate;
    }

    // Getters and Setters
    public String getReportId() {
        return reportId;
    }

    public void setReportId(String reportId) {
        this.reportId = reportId;
    }

    public String getOffendingVin() {
        return offendingVin;
    }

    public void setOffendingVin(String offendingVin) {
        this.offendingVin = offendingVin;
    }

    public String getVictimVin() {
        return victimVin;
    }

    public void setVictimVin(String victimVin) {
        this.victimVin = victimVin;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public Date getReportDate() {
        return reportDate;
    }

    public void setReportDate(Date reportDate) {
        this.reportDate = reportDate;
    }
}
