package com.vehiclemanagement.model;
import java.util.Date;
import java.util.List;

public class FitnessCertificate {
	private int id;
    private Date date;

    public FitnessCertificate(int id, Date date) {
        this.id = id;
        this.date = date;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }
}