package com.vehiclemanagement.model;
public class InsuranceCompany {
    private String name;
    private String address;

    // Constructor
    public InsuranceCompany(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public InsuranceCompany() {
        
    }
    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
