package com.vehiclemanagement.model;
import java.util.Date;
import java.util.List;

public class InsurancePolicy {
	private int id;
    private Date date;

    public InsurancePolicy(int id, Date date) {
        this.id = id;
        this.date = date;
    }
    public InsurancePolicy() {
        
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }
}