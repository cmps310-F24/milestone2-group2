package com.vehiclemanagement.model;

public class Invoice {
	private int id;
    private float amount;
    private Vehicle vehicle;
    private boolean paid;

    public Invoice(int id, float amount, Vehicle vehicle, boolean paid) {
        this.id = id;
        this.amount = amount;
        this.vehicle = vehicle;
        this.paid = paid;
    }
    public Invoice() {
        
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public float getAmount() { return amount; }
    public void setAmount(float amount) { this.amount = amount; }

    public Vehicle getVehicle() { return vehicle; }
    public void setVehicle(Vehicle vehicle) { this.vehicle = vehicle; }

    public boolean isPaid() { return paid; }
    public void setPaid(boolean paid) { this.paid = paid; }
}