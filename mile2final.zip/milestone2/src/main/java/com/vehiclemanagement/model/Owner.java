package com.vehiclemanagement.model;

public class Owner {
	private String name;
    private int QID;
    private int mobile;

    public Owner(String name, int QID, int mobile) {
        this.name = name;
        this.QID = QID;
        this.mobile = mobile;
    }
    public Owner() {
        
    }

    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getQID() { return QID; }
    public void setQID(int QID) { this.QID = QID; }

    public int getMobile() { return mobile; }
    public void setMobile(int mobile) { this.mobile = mobile; }

    public void register() {
        System.out.println("Owner registered: " + name);
    }


}