package com.vehiclemanagement.model;
import java.util.Date;
import java.util.List;


public class RedLightOffence {
	  private Vehicle vehicle;
	    private Date date;
	    private String type;

	    public RedLightOffence(Vehicle vehicle, Date date, String type) {
	        this.vehicle = vehicle;
	        this.date = date;
	        this.type = type;
	    }

	    // Getters and Setters
	    public Vehicle getVehicle() { return vehicle; }
	    public void setVehicle(Vehicle vehicle) { this.vehicle = vehicle; }

	    public Date getDate() { return date; }
	    public void setDate(Date date) { this.date = date; }

	    public String getType() { return type; }
	    public void setType(String type) { this.type = type; }
	}

	// TrafficPolice class
	class TrafficPolice {
	    private Date loginDate;

	    public TrafficPolice(Date loginDate) {
	        this.loginDate = loginDate;
	    }

	    // Getters and Setters
	    public Date getLoginDate() { return loginDate; }
	    public void setLoginDate(Date loginDate) { this.loginDate = loginDate; }

	    public void confirmConfiscatingOrder() {
	        System.out.println("Confiscating order confirmed.");
	    }

	    public void listRedLightOffences(Date period, String type) {
	        System.out.println("Listing Red Light Offences of type: " + type);
	    }
	}