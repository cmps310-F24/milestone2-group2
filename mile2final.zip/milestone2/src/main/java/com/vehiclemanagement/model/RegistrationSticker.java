package com.vehiclemanagement.model;

import java.util.Date;

public class RegistrationSticker {

    private int vin;             // Vehicle Identification Number (VIN)
    private String ownerName;    // Name of the new owner
    private Date issueDate;      // Date when the registration sticker was issued

    // Constructor
    public RegistrationSticker(int vin, String ownerName, Date issueDate) {
        this.vin = vin;
        this.ownerName = ownerName;
        this.issueDate = issueDate;
    }
    public RegistrationSticker() {
        
    }

    // Getter and Setter for VIN
    public int getVin() {
        return vin;
    }

    public void setVin(int vin) {
        this.vin = vin;
    }

    // Getter and Setter for Owner Name
    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    // Getter and Setter for Issue Date
    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    @Override
    public String toString() {
        return "RegistrationSticker{" +
                "vin=" + vin +
                ", ownerName='" + ownerName + '\'' +
                ", issueDate=" + issueDate +
                '}';
    }
}
