package com.vehiclemanagement.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Vehicle {
    private int VIN;
    private String make;
    private String model;
    private int year;
    private Owner owner;
    private InsurancePolicy insurancePolicy;
    private FitnessCertificate fitnessCertificate;
    private List<Invoice> invoices;
    private List<RedLightOffence> offences;

    public Vehicle(int VIN, String make, String model, int year, Owner owner) {
        this.VIN = VIN;
        this.make = make;
        this.model = model;
        this.year = year;
        this.owner = owner;
        this.invoices = new ArrayList<>();  // Initialize the invoices list
    }
    public Vehicle() {
        
    }

   

    // Getters and Setters
    public int getVIN() { return VIN; }
    public void setVIN(int VIN) { this.VIN = VIN; }

    public String getMake() { return make; }
    public void setMake(String make) { this.make = make; }

    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }

    public Owner getOwner() { return owner; }
    public void setOwner(Owner owner) { this.owner = owner; }

    public InsurancePolicy getInsurancePolicy() { return insurancePolicy; }
    public void setInsurancePolicy(InsurancePolicy insurancePolicy) { this.insurancePolicy = insurancePolicy; }

    public FitnessCertificate getFitnessCertificate() { return fitnessCertificate; }
    public void setFitnessCertificate(FitnessCertificate fitnessCertificate) { this.fitnessCertificate = fitnessCertificate; }

    public List<Invoice> getInvoices() { return invoices; }
    public void setInvoices(List<Invoice> invoices) { this.invoices = invoices; }

    public List<RedLightOffence> getOffences() { return offences; }
    public void setOffences(List<RedLightOffence> offences) { this.offences = offences; }
}