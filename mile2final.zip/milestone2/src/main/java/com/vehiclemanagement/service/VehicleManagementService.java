package com.vehiclemanagement.service;

import com.vehiclemanagement.model.Owner;
import com.vehiclemanagement.model.Vehicle;
import com.vehiclemanagement.model.AccidentReport;
import com.vehiclemanagement.model.Invoice;
import com.vehiclemanagement.model.RegistrationSticker;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class VehicleManagementService {

    private final List<Owner> owners = new ArrayList<>();
    private final List<Vehicle> vehicles = new ArrayList<>();
    private final List<AccidentReport> accidentReports = new ArrayList<>();
    private final List<Invoice> invoices = new ArrayList<>();
    private final List<RegistrationSticker> registrationStickers = new ArrayList<>();

    public VehicleManagementService() {
        // owners
        Owner owner1 = new Owner("ahmed", 12324, 123216789);
        Owner owner2 = new Owner("Omar", 12345, 987654321);
        Owner owner3 = new Owner("ali", 67890, 123456789);
        owners.add(owner1);
        owners.add(owner2);

        // vehicles
        vehicles.add(new Vehicle(123, "Toyota", "Corolla", 2020, owner1));
        vehicles.add(new Vehicle(456, "Honda", "Civic", 2021, owner2));

        // accident reports
        accidentReports.add(new AccidentReport("R001", "123", "456", "Minor collision", new Date()));
        accidentReports.add(new AccidentReport("R002", "789", "012", "Major collision", new Date()));
    }

    public List<Owner> getOwners() {
        return owners;
    }

    public List<Vehicle> getVehicles() {
        return vehicles;
    }

    public List<AccidentReport> getAccidentReports() {
        return accidentReports;
    }

    // Updates the owner's name based on the QID
    public void updateOwner(int qid, String newName) {
        owners.stream().filter(owner -> owner.getQID() == qid).findFirst().ifPresent(owner -> owner.setName(newName));
    }

    // Updates the vehicle owner based on VIN
    public void updateVehicleOwner(int vin, Owner newOwner) {
        vehicles.stream()
                .filter(vehicle -> vehicle.getVIN() == vin)
                .findFirst()
                .ifPresent(vehicle -> vehicle.setOwner(newOwner));
    }
    public boolean validateOwnerDetails(int qid, String name) {
        return owners.stream()
                .anyMatch(owner -> owner.getQID() == qid && owner.getName().equalsIgnoreCase(name));
    }


 // Check if there are unpaid bills for a vehicle
    public boolean checkUnpaidBills(int vin) {
        Vehicle vehicle = findVehicleByVin(vin);

        if (vehicle == null) {
            System.out.println("Vehicle with VIN " + vin + " not found.");
            return false;
        }

        for (Invoice invoice : vehicle.getInvoices()) {
            if (!invoice.isPaid()) { 
                return true; 
            }
        }
        return false;
    }

    // Create an invoice for the vehicle 
    public void createInvoice(int vin) {
        Vehicle vehicle = vehicles.stream()
                                   .filter(v -> v.getVIN() == vin)
                                   .findFirst()
                                   .orElse(null);
        if (vehicle != null) {
            int invoiceId = vehicle.getInvoices().size() + 1; 
            Invoice invoice = new Invoice(invoiceId, 100, vehicle, false); 
            vehicle.getInvoices().add(invoice); 
        }
    }

    // Prepare a registration sticker for the new owner (simulated)
    public void prepareRegistrationSticker(int vin, Owner newOwner) {
        RegistrationSticker sticker = new RegistrationSticker(vin, newOwner.getName(), new Date());
        registrationStickers.add(sticker);
    }
    
    public Vehicle findVehicleByVin(int vin) {
        return vehicles.stream()
            .filter(vehicle -> vehicle.getVIN() == vin)
            .findFirst()
            .orElse(null);
    }
    

}
