package UCT1;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.Invoice;
import com.vehiclemanagement.model.Vehicle;

class InvoiceTest {
	
	 //public Invoice(int id, float amount, Vehicle vehicle, boolean paid) 
	Invoice invoice=new Invoice(2023,3034,null,false);

	@Test
	void testInvoice() {
		testGetId();
		testGetAmount();
		testGetVehicle();
		testIsPaid();
	}

	@Test
	void testGetId() {
		assertEquals(2023,invoice.getId());
	}

	@Test
	void testGetAmount() {
		assertEquals(3034,invoice.getAmount());
	}

	@Test
	void testGetVehicle() {
		assertEquals(null,invoice.getVehicle());
	}

	@Test
	void testIsPaid() {
		assertEquals(false,invoice.isPaid());
	}

}
