package UCT1;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.Invoice;
import com.vehiclemanagement.model.Vehicle;

class InvoiceTest2 {
	
	 //public Invoice(int id, float amount, Vehicle vehicle, boolean paid) 
	Invoice invoice=new Invoice();

	@Test
	void testInvoice() {
		testGetId();
		testGetAmount();
		testGetVehicle();
		testIsPaid();
	}

	@Test
	void testGetId() {
		assertEquals(0,invoice.getId());
	}

	@Test
	void testGetAmount() {
		assertEquals(0,invoice.getAmount());
	}

	@Test
	void testGetVehicle() {
		assertEquals(null,invoice.getVehicle());
	}

	@Test
	void testIsPaid() {
		assertEquals(false,invoice.isPaid());
	}

}
