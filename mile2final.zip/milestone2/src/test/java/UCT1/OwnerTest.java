package UCT1;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.Owner;

class OwnerTest {
	// public Owner(String name, int QID, int mobile)
	Owner owner=new Owner("ahmed",2023,44332211);
	
	@Test
	void testOwner() {
		testGetName();
		testGetQID();
		testGetMobile();
	}

	@Test
	void testGetName() {
		assertEquals("ahmed",owner.getName());
	}

	@Test
	void testGetQID() {
		assertEquals(2023,owner.getQID());
	}

	@Test
	void testGetMobile() {
		assertEquals(44332211,owner.getMobile());
	}

}
