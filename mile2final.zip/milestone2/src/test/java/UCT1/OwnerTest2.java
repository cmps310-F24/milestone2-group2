package UCT1;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.Owner;

class OwnerTest2 {
	// public Owner(String name, int QID, int mobile)
	Owner owner=new Owner();
	
	@Test
	void testOwner() {
		testGetName();
		testGetQID();
		testGetMobile();
	}

	@Test
	void testGetName() {
		assertEquals(null,owner.getName());
	}

	@Test
	void testGetQID() {
		assertEquals(0,owner.getQID());
	}

	@Test
	void testGetMobile() {
		assertEquals(0,owner.getMobile());
	}

}
