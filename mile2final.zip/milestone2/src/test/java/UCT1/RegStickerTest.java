package UCT1;


import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.RegistrationSticker;

class RegStickerTest {
	// public RegistrationSticker(int vin, String ownerName, Date issueDate)
	RegistrationSticker regsticker=new RegistrationSticker(2023,"ahmed",null);

	@Test
	void testRegistrationSticker() {
		testGetVin();
		testGetOwnerName();
		testGetIssueDate();
	}

	@Test
	void testGetVin() {
		assertEquals(2023,regsticker.getVin());

	}

	@Test
	void testGetOwnerName() {
		assertEquals("ahmed",regsticker.getOwnerName());

	}

	@Test
	void testGetIssueDate() {
		assertEquals(null,regsticker.getIssueDate());

	}

}
