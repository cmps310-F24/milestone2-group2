package UCT1;


import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.RegistrationSticker;

class RegStickerTest2 {
	// public RegistrationSticker(int vin, String ownerName, Date issueDate)
	RegistrationSticker regsticker=new RegistrationSticker();

	@Test
	void testRegistrationSticker() {
		testGetVin();
		testGetOwnerName();
		testGetIssueDate();
	}

	@Test
	void testGetVin() {
		assertEquals(0,regsticker.getVin());

	}

	@Test
	void testGetOwnerName() {
		assertEquals(null,regsticker.getOwnerName());

	}

	@Test
	void testGetIssueDate() {
		assertEquals(null,regsticker.getIssueDate());

	}

}
