package UCT1;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.Owner;
import com.vehiclemanagement.model.Vehicle;

class VehicleTest2 {
	
	//public Vehicle(int VIN, String make, String model, int year, Owner owner) 
	
	Vehicle vehicle= new Vehicle();

	@Test
	void testVehicle() {
		testGetVIN();
		testGetMake();
		testGetModel();
		testGetYear();
		testGetOwner();
		testGetFitnessCertificate();
		testGetInsurancePolicy();
	}

	@Test
	void testGetVIN() {
		assertEquals(0,vehicle.getVIN());
	}

	@Test
	void testGetMake() {
		assertEquals(null,vehicle.getMake());
	}

	@Test
	void testGetModel() {
		assertEquals(null,vehicle.getModel());
	}

	@Test
	void testGetYear() {
		assertEquals(0,vehicle.getYear());
	}

	@Test
	void testGetOwner() {
		assertEquals(null,vehicle.getOwner());
	}
	
	@Test
	void testGetFitnessCertificate() {
		assertEquals(null,vehicle.getFitnessCertificate());

	}
	
	@Test
	void testGetInsurancePolicy() {
		assertEquals(null,vehicle.getInsurancePolicy());

	}
	
	

}
