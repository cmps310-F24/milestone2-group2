package UCT2;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.AccidentReport;

class AccidentReportTest {
	//public AccidentReport(String reportId, String offendingVin, String victimVin, String details, Date reportDate)
	AccidentReport accreport= new AccidentReport("report1","111","222","details",null);
	@Test
	void testAccidentReportStringStringStringStringDate() {
		testGetReportId();
		testGetOffendingVin();
		testGetVictimVin();
		testGetDetails();
		testGetReportDate();
	}

	@Test
	void testGetReportId() {
		assertEquals("report1",accreport.getReportId());

	}

	@Test
	void testGetOffendingVin() {
		assertEquals("111",accreport.getOffendingVin());
	}

	@Test
	void testGetVictimVin() {
		assertEquals("222",accreport.getVictimVin());
	}

	@Test
	void testGetDetails() {
		assertEquals("details",accreport.getDetails());
	}

	@Test
	void testGetReportDate() {
		assertEquals(null,accreport.getReportDate());
	}

}
