package UCT2;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.AccidentReport;

class AccidentReportTest2 {
	//public AccidentReport(String reportId, String offendingVin, String victimVin, String details, Date reportDate)
	AccidentReport accreport= new AccidentReport();
	@Test
	void testAccidentReportStringStringStringStringDate() {
		testGetReportId();
		testGetOffendingVin();
		testGetVictimVin();
		testGetDetails();
		testGetReportDate();
	}

	@Test
	void testGetReportId() {
		assertEquals(null,accreport.getReportId());

	}

	@Test
	void testGetOffendingVin() {
		assertEquals(null,accreport.getOffendingVin());
	}

	@Test
	void testGetVictimVin() {
		assertEquals(null,accreport.getVictimVin());
	}

	@Test
	void testGetDetails() {
		assertEquals(null,accreport.getDetails());
	}

	@Test
	void testGetReportDate() {
		assertEquals(null,accreport.getReportDate());
	}

}
