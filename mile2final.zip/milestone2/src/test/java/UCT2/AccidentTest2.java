package UCT2;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.Accident;
import com.vehiclemanagement.model.Vehicle;

class AccidentTest2 {
	//    public Accident(Date date, Date time, String location, String briefDescription, Vehicle victim, Vehicle offendingVehicle, int caseNo) {
	Accident accident=new Accident();
	
	@Test
	void testAccident() {
		testGetDate();
		testGetTime();
		testGetLocation();
		testGetBriefDescription();
		testGetVictim();
		testGetOffendingVehicle();
		testGetCaseNo();
		}

	@Test
	void testGetDate() {
		assertEquals(null,accident.getDate());
	}

	@Test
	void testGetTime() {
		assertEquals(null,accident.getTime());
	}

	@Test
	void testGetLocation() {
		assertEquals(null,accident.getLocation());
	}

	@Test
	void testGetBriefDescription() {
		assertEquals(null,accident.getBriefDescription());
	}

	@Test
	void testGetVictim() {
		assertEquals(null,accident.getVictim());
	}

	@Test
	void testGetOffendingVehicle() {
		assertEquals(null,accident.getOffendingVehicle());
	}

	@Test
	void testGetCaseNo() {
		assertEquals(0,accident.getCaseNo());
	}

}
