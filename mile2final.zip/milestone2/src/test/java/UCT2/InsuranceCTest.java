package UCT2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.InsuranceCompany;

class InsuranceCTest {
	//public InsuranceCompany(String name, String address)
	InsuranceCompany ic=new InsuranceCompany("ahmed","central park");

	@Test
	void testInsuranceCompany() {
		testGetName();
		testGetAddress();
		}

	@Test
	void testGetName() {
		assertEquals("ahmed",ic.getName());
	}

	@Test
	void testGetAddress() {
		assertEquals("central park",ic.getAddress());
	}

}
