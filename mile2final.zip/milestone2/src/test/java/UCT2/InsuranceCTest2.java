package UCT2;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.InsuranceCompany;

class InsuranceCTest2 {
	//public InsuranceCompany(String name, String address)
	InsuranceCompany ic=new InsuranceCompany();

	@Test
	void testInsuranceCompany() {
		testGetName();
		testGetAddress();
		}

	@Test
	void testGetName() {
		assertEquals(null,ic.getName());
	}

	@Test
	void testGetAddress() {
		assertEquals(null,ic.getAddress());
	}

}
