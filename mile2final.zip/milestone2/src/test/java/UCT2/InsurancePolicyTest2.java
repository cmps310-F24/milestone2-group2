package UCT2;


import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.InsurancePolicy;

class InsurancePolicyTest2 {
	// public InsurancePolicy(int id, Date date)
	InsurancePolicy ip=new InsurancePolicy();

	@Test
	void testInsurancePolicy() {
		testGetId();
		testGetDate();
	}

	@Test
	void testGetId() {
		assertEquals(0,ip.getId());
	}

	@Test
	void testGetDate() {
		assertEquals(null,ip.getDate());
	}

}
