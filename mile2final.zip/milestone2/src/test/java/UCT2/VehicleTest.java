package UCT2;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.vehiclemanagement.model.Owner;
import com.vehiclemanagement.model.Vehicle;

class VehicleTest {
	
	//public Vehicle(int VIN, String make, String model, int year, Owner owner) 
	
	Vehicle vehicle= new Vehicle(1,"make1","model1",2024,null);

	@Test
	void testVehicle() {
		testGetVIN();
		testGetMake();
		testGetModel();
		testGetYear();
		testGetOwner();
		testGetFitnessCertificate();
		testGetInsurancePolicy();
	}

	@Test
	void testGetVIN() {
		assertEquals(1,vehicle.getVIN());
	}

	@Test
	void testGetMake() {
		assertEquals("make1",vehicle.getMake());
	}

	@Test
	void testGetModel() {
		assertEquals("model1",vehicle.getModel());
	}

	@Test
	void testGetYear() {
		assertEquals(2024,vehicle.getYear());
	}

	@Test
	void testGetOwner() {
		assertEquals(null,vehicle.getOwner());
	}
	
	@Test
	void testGetFitnessCertificate() {
		assertEquals(null,vehicle.getFitnessCertificate());

	}
	
	@Test
	void testGetInsurancePolicy() {
		assertEquals(null,vehicle.getInsurancePolicy());

	}
	
	

}
